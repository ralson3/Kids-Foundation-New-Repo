import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_yemian/index.dart';

class IndexPage1 extends StatefulWidget {
  @override
  _IndexPage1State createState() => _IndexPage1State();
}

class _IndexPage1State extends State<IndexPage1> {
  bool isShow = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffF6F6F6),
      body: Container(
        decoration: BoxDecoration(
          image: new DecorationImage(
            fit: BoxFit.cover,
            image: new AssetImage(
                'images/18.jpg'),
          ),
        ),
        child: Column(
          children: <Widget>[
            SizedBox(height: 30,),
            Image.asset('images/11.jpg',height: 60,width: 80,),
            SizedBox(height: 20,),
            Row(
              children: <Widget>[
                SizedBox(width: 15,),
                Expanded(flex: 1,
                  child: InkWell(
                    onTap: (){
                      toPage('images/19.jpg');
                    },
                    child: Image.asset('images/12.jpg'),
                  ),
                ),
                SizedBox(width: 25,),
                Expanded(flex: 1,
                  child: InkWell(
                    onTap: (){
                      toPage('images/20.jpg');
                    },
                    child: Image.asset('images/13.jpg'),
                  ),
                ),
                SizedBox(width: 25,),
                Expanded(flex: 1,child: Image.asset('images/14.jpg'),),
                SizedBox(width: 15,),
              ],
            ),
            SizedBox(height: 20,),
            Row(
              children: <Widget>[
                SizedBox(width: 15,),
                Expanded(flex: 1,child: Image.asset('images/15.jpg'),),
                SizedBox(width: 25,),
                Expanded(flex: 1,child: Image.asset('images/16.jpg'),),
                SizedBox(width: 25,),
                Expanded(flex: 1,child: Image.asset('images/17.jpg'),),
                SizedBox(width: 15,),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: (){},
        child: Icon(Icons.email),
      ),
    );
  }

  toPage(String img){
    Navigator.push(context, MaterialPageRoute(builder: (_) {
      return new IndexPage(img);
    }));
  }
}
